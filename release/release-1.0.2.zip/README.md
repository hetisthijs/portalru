# Radboud University Portal
Chrome extension for Radboud University Student Portal to quickly see all notifications (Timetable, Blackboard and more)

![Screenshot](https://github.com/hetisthijs/portalru/blob/master/screenshot.png?raw=true)
